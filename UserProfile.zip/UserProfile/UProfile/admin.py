# UProfile/admin.py

from django.contrib import admin
from .models import UserProfile

class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('username', 'name', 'email', 'company', 'birthday', 'country', 'university_name', 'location')
    search_fields = ('username', 'name', 'email')
    list_filter = ('country', 'university_name', 'location')  # Add more filters as needed
    ordering = ('username',)  # Default ordering
    
    fieldsets = (
        ('Profile Information', {
            'fields': ('username', 'name', 'email', 'company', 'birthday', 'country', 'university_name', 'location')
        }),
        ('Social Links', {
            'fields': ('twitter', 'facebook', 'google_plus', 'linkedin', 'instagram')
        }),
    )
    
    # Customize other admin options as needed

admin.site.register(UserProfile, UserProfileAdmin)

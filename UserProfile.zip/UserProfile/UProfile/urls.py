# UProfile/urls.py

from django.urls import path
from .views import profile_view

app_name = 'UProfile'

urlpatterns = [
    path('profile/', profile_view, name='profile'),
    # Add more URL patterns as needed
]

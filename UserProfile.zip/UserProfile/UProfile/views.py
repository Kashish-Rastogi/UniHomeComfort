# UProfile/views.py

from django.shortcuts import render, redirect
from .models import UserProfile

def profile_view(request):
    user_profile = UserProfile.objects.get(username='nmaxwell')
    return render(request, 'UProfile/profile_template.html', {'user_profile': user_profile})

def update_profile(request):
    if request.method == 'POST':
        return redirect('UProfile:profile')  # Redirect to the profile view after updating
    return render(request, 'UProfile/update_profile_template.html')
